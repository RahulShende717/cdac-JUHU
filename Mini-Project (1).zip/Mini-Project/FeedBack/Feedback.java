//package FeedBack;
import java.util.*;
public class Feedback{
	public static void main(String args[]){
	Scanner sc = new Scanner(System.in);
	System.out.println("Please Rate Your Experience On Our Site");
	int n = sc.nextInt();
	if(n>5){
		System.out.print(" Invalid !!! ");
		System.out.print("Please Rate Between 1 to 5 Stars");
		return;
	}
	for(int i=1; i<=n; i++){
		System.out.print(" * ");
		
	}
	}
}