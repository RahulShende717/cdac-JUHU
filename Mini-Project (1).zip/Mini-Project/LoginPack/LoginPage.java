package LoginPack;
import java.util.*;
class Data{
	private String User_name;
	private String Password;
	
	Data(String User_name, String Password){
		this.User_name = User_name;
		this.Password = Password;
	}
	public String getName(){
		return this.User_name;
	}
	public void setName(String User_name){
		this.User_name = User_name;
	}
	
	public String getPassword(){
		return this.Password;
	}
	public void setPassword(String Password){
		this.Password = Password;
	}
}


public class LoginPage{

public void LoginPageMethod(){
Scanner sc = new Scanner(System.in);
System.out.println("# *----Lamborghini Authorized Dealer----* #");
System.out.println(" WELCOME TO Lamborghini.com!!!!!! ");
System.out.println("PLEASE ENTER YOUR DETAILS TO SIGN UP");
System.out.println("Please Enter Your User Name");
String s1 = sc.nextLine();
System.out.println("Please Enter Your Password");
String s2 = sc.nextLine();
System.out.println(" $$$$..Welcome To Galaxy Automotives..$$$$");

Data d = new Data(s1,s2);
System.out.println("Thank you For Login Details !! "+d.getName());
System.out.println("Hello "+d.getName());
System.out.println("Please Proceed For Booking...");
}
}
