package RunPack;
import LoginPack.LoginPage;
import MainPack.MiniDsa;
class Run{
	public static void main(String args[]){
		LoginPage lp = new LoginPage();
		lp.LoginPageMethod();
		MiniDsa mn= new MiniDsa();
		mn.cstChoose();
		mn.display();
}
}