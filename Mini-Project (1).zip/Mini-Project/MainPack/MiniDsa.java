package MainPack;
import java.util.Scanner;
public class MiniDsa
{  
   
     Node head1;
	 Node head2;
	 Node head3;
	 class Node
	 {
	   String data;
	   Node next;
	   
	   Node(String data)
	   {
	    this.data=data;
		next=null;
	   }
	 }
	   
//---------------------------------------------------------------	   
	   
	   
	   
   
   public void urusAppend(String s1)
   {
    Node new_node=new Node(s1);
	if(head1==null)
	{
	 head1=new_node;
	 //new_node.next=null;
	 return;
	}
	Node n=head1;
	while(n.next!=null)
	{
	 n=n.next;
	}
	n.next=new_node;
	new_node.next=null;
	return;
	}
	
//---------------------------------------------------------------------	

   public void avantadorAppend(String s2)
   {
    Node new_node=new Node(s2);
	if(head2==null)
	{
	 head2=new_node;
	// new_node.next=null;
	 return;
	}
	Node n=head2;
	while(n.next!=null)
	{
	 n=n.next;
	}
	n.next=new_node;
	new_node.next=null;
	return;
	}
//---------------------------------------------------------------------------	
	
	
	
   public void huracanAppend(String s3)
   {
    Node new_node=new Node(s3);
	if(head3==null)
	{
	 head3=new_node;
	// new_node.next=null;
	 return;
	}
	Node n=head3;
	while(n.next!=null)
	{
	 n=n.next;
	}
	n.next=new_node;
	new_node.next=null;
	return;
	}
//----------------------------------------------------------------------------------- 
   public void display()
   {
   System.out.println();
   System.out.println("====>>>>>>>>List Of Order Of  URUS<<<<<<<<====");
   Node n1=head1;
   while(n1!=null)
   {
     System.out.println(n1.data);
	 n1=n1.next;
   }
   System.out.println();
   System.out.println("====>>>>>>>>List Of Order Of Avantador<<<<<<<<====");
   Node n2=head2;
   while(n2!=null)
   {
     System.out.println(n2.data);
	 n2=n2.next;
   }
   System.out.println();
   System.out.println("====>>>>>>>>List of URUS Huracan<<<<<<<<====");
    Node n3=head3;
   while(n3!=null)
   {
     System.out.println(n3.data);
	 n3=n3.next;
   }
   }
   
 //---------------------------------------------------------------------------------  
   
      
  public void cstChoose()
  {
  do{
  System.out.println("PLEASE REGISTERE YOUR LAMBORGHINI CAR SIR ");
  System.out.println("--------------------");
  System.out.println();
  System.out.println(" 1====>>>>>>>>   LAMBO URUS       <<<<<<<<====  ");  
  System.out.println(" 2====>>>>>>>>   LAMBO AVENTADOR  <<<<<<<<====  ");
  System.out.println(" 3====>>>>>>>>   LAMBO HURACAN    <<<<<<<<====  ");
  System.out.println(" 4====>>>>>>>>   RETURN           <<<<<<<<====  ");
  System.out.println();
  System.out.println("--------------------");
  System.out.println("ENTER HERE>>>>>>>  ");
  
  Scanner sc =new Scanner(System.in);
  int ch=sc.nextInt();
  switch(ch)
  {
   case 1:System.out.println("====>>>>>>>> Please Enter The Car Colour <<<<<<<<====");
          String s1=sc.next();
          urusAppend(s1);
          break;
   case 2:System.out.println("====>>>>>>>> Please Enter The Car Colour <<<<<<<<====");
          String s2=sc.next();
          avantadorAppend(s2);
          break;
   case 3:System.out.println("====>>>>>>>> Please Enter The Car Colour <<<<<<<<====");
          String s3=sc.next();
          huracanAppend(s3);
          break;
   case 4:return;	  
		  
   default:System.out.println("====>>>>>>>>Input Is Not Valid Sir<<<<<<<<====");	
          break;   
  }
  }while(1==1);
  }
  
  
  
 /* public static void main(String args[])
  {
   LoginPage lp = new LoginPage();
   lp.LoginPageMethod();
   MiniDsa mn= new MiniDsa();
   mn.cstChoose();
   mn.display();
   
   
  }*/
}